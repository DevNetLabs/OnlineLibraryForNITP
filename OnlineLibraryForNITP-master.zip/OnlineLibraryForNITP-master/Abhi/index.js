import react from "react";
import reactDOM from "react-dom";

import IndexComponent from './IndexComponent';

ReactDOM.render(<IndexComponent />, document.getElementById('root'));
